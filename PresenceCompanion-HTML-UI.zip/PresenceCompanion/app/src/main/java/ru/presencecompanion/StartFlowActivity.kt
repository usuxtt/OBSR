package ru.presencecompanion

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * Невидимая точка входа для ярлыка: запускает Chrome и цепочку split screen -> шторка ИИ,
 * не показывая главный экран. Сразу закрывается.
 */
class StartFlowActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val service = SplitScreenService.instance
        val chrome = packageManager.getLaunchIntentForPackage("com.android.chrome")

        when {
            service == null -> {
                Toast.makeText(
                    this,
                    "Включите Presence Companion в «Специальных возможностях»",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            chrome == null -> {
                Toast.makeText(this, "Chrome не найден", Toast.LENGTH_SHORT).show()
            }
            else -> {
                startActivity(chrome.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                service.runFlow()
            }
        }
        finish()
    }
}
