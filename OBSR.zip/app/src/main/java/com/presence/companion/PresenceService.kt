package com.presence.companion

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.view.ContextThemeWrapper
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/**
 * Всё живёт в службе специальных возможностей:
 *  - плавающий таймер (сек:сотые) + кнопка мгновенного скриншота (TYPE_ACCESSIBILITY_OVERLAY, без разрешения «поверх окон»)
 *  - выбор ИИ в нижней половине экрана
 *  - тап по окну ИИ -> таймер 5 сек, тап по окну Chrome -> сброс
 */
class PresenceService : AccessibilityService() {

    companion object {
        @Volatile var instance: PresenceService? = null
        const val CHROME = "com.android.chrome"
        // Ищем среди УСТАНОВЛЕННЫХ приложений по названию/пакету (порядок = порядок в выборе)
        val AI_KEYS = listOf("claude", "chatgpt", "qwen", "deepseek", "gemini")
        const val TOTAL_MS = 5000L
    }

    private val h = Handler(Looper.getMainLooper())
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }
    private val ui by lazy { ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog) }

    private var bar: View? = null
    private var picker: View? = null
    private var thumb: View? = null
    private lateinit var timerText: TextView

    private var active = false
    private var aiPkg: String? = null
    private var ignoreUntil = 0L
    private var pendingSplit = false
    private var startAt = 0L

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stop()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    /** Вызывается кнопкой СТАРТ. */
    fun start() {
        stop()
        active = true
        aiPkg = null
        ignoreUntil = SystemClock.elapsedRealtime() + 2500
        showBar()
        pendingSplit = true
        launch(CHROME, adjacent = false)
        // запасной вариант: если событие от Chrome не пришло — делим через 4 секунды
        h.postDelayed({ if (pendingSplit) doSplit() }, 4000)
    }

    /** Делит экран: текущее окно (Chrome) вверх, затем показывает выбор ИИ внизу. */
    private fun doSplit() {
        pendingSplit = false
        val ok = performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
        if (!ok) Toast.makeText(this, "Система не приняла команду разделения экрана", Toast.LENGTH_LONG).show()
        h.postDelayed({ showPicker() }, 800)
    }

    private fun stop() {
        active = false
        pendingSplit = false
        h.removeCallbacksAndMessages(null)
        listOf(bar, picker, thumb).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        bar = null; picker = null; thumb = null
    }

    // ---------- события: тапы по окнам ----------

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!active) return
        if (pendingSplit && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            e.packageName?.toString() == CHROME) {
            pendingSplit = false
            h.postDelayed({ doSplit() }, 700)   // Chrome на экране — делим
            return
        }
        if (SystemClock.elapsedRealtime() < ignoreUntil) return
        val pkg = if (e.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED)
            windows.firstOrNull { it.isActive }?.root?.packageName?.toString()
        else e.packageName?.toString()
        when {
            pkg == null || pkg == packageName -> return
            pkg == CHROME -> resetTimer()
            pkg == aiPkg -> startTimer()
        }
    }

    // ---------- таймер ----------

    private val tick = object : Runnable {
        override fun run() {
            val left = TOTAL_MS - (SystemClock.elapsedRealtime() - startAt)
            if (left <= 0) {
                render(0, red = true)
                vibrate()
            } else {
                render(left)
                h.postDelayed(this, 10)
            }
        }
    }

    private fun startTimer() {
        startAt = SystemClock.elapsedRealtime()
        h.removeCallbacks(tick)
        h.post(tick)
    }

    private fun resetTimer() {
        h.removeCallbacks(tick)
        render(0)
    }

    /** left — оставшиеся мс. Цвет: зелёный (hue 120) -> красный (hue 0) пропорционально. */
    private fun render(left: Long, red: Boolean = false) {
        timerText.text = "${left / 1000}:${"%02d".format((left % 1000) / 10)}"
        val hue = if (red) 0f else 120f * (if (left == 0L) 1f else left.toFloat() / TOTAL_MS)
        timerText.setTextColor(Color.HSVToColor(floatArrayOf(hue, 1f, 0.95f)))
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    // ---------- окна-оверлеи ----------

    private fun overlayParams(w: Int, hgt: Int, gravity: Int) = WindowManager.LayoutParams(
        w, hgt,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showBar() {
        val row = LinearLayout(ui).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(2), dp(10), dp(2))
            background = GradientDrawable().apply {
                setColor(0xCC000000.toInt()); cornerRadius = dp(18).toFloat()
            }
        }
        val shot = ImageButton(ui).apply {
            setImageResource(android.R.drawable.ic_menu_camera)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { shoot() }
        }
        timerText = TextView(ui).apply {
            textSize = 20f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            // долгое нажатие на таймер — выключить оверлеи
            setOnLongClickListener { stop(); true }
        }
        val split = TextView(ui).apply {
            text = "⧉"; textSize = 24f; setTextColor(Color.WHITE)
            setPadding(dp(10), 0, dp(10), 0)
            // ручной повтор: поделить экран и заново показать выбор ИИ
            setOnClickListener { aiPkg = null; doSplit() }
        }
        row.addView(split)
        row.addView(shot)
        row.addView(timerText)
        val lp = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END
        ).apply { x = dp(10); y = dp(6) }
        wm.addView(row, lp)
        bar = row
        render(0)
    }

    private class AiApp(val label: String, val pkg: String, val icon: Drawable)

    private fun findAiApps(): List<AiApp> {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        fun rank(label: String, pkg: String) =
            AI_KEYS.indexOfFirst { label.contains(it, true) || pkg.contains(it, true) }
        return packageManager.queryIntentActivities(q, 0).mapNotNull { ri ->
            val label = ri.loadLabel(packageManager).toString()
            val pkg = ri.activityInfo.packageName
            if (rank(label, pkg) >= 0) AiApp(label, pkg, ri.loadIcon(packageManager)) else null
        }.distinctBy { it.pkg }.sortedBy { rank(it.label, it.pkg) }
    }

    private fun showPicker() {
        if (!active || picker != null) return
        val apps = findAiApps()
        if (apps.isEmpty()) {
            Toast.makeText(this, "Не нашёл установленных ИИ-приложений", Toast.LENGTH_LONG).show()
            return
        }
        val screenH = wm.currentWindowMetrics.bounds.height()
        val col = LinearLayout(ui).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(0xF0202124.toInt()); cornerRadius = dp(20).toFloat()
            }
        }
        col.addView(TextView(ui).apply {
            text = "AI"; textSize = 18f; setTextColor(Color.WHITE)
        })
        // сетка иконок вашей папки: по 3 в ряд, как на рисунке 1
        apps.chunked(3).forEach { rowApps ->
            val row = LinearLayout(ui).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app ->
                val cell = LinearLayout(ui).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setOnClickListener { choose(app.pkg) }
                }
                cell.addView(ImageView(ui).apply { setImageDrawable(app.icon) },
                    LinearLayout.LayoutParams(dp(56), dp(56)))
                cell.addView(TextView(ui).apply {
                    text = app.label; textSize = 12f; setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER; maxLines = 1
                })
                row.addView(cell, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            }
            repeat(3 - rowApps.size) { row.addView(View(ui), LinearLayout.LayoutParams(0, 1, 1f)) }
            col.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        wm.addView(col, overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT, screenH / 2, Gravity.BOTTOM
        ))
        picker = col
    }

    private fun choose(pkg: String) {
        aiPkg = pkg
        picker?.let { runCatching { wm.removeView(it) } }   // выбор ИИ скрывается
        picker = null
        ignoreUntil = SystemClock.elapsedRealtime() + 2500  // не считать запуск окна нажатием
        launch(pkg, adjacent = true)
    }

    private fun launch(pkg: String, adjacent: Boolean) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(this, "Не найдено приложение: $pkg", Toast.LENGTH_LONG).show()
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (adjacent) i.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        startActivity(i)
    }

    // ---------- скриншот фрагмента (окно Chrome) ----------

    private fun shoot() {
        removeThumb()
        bar?.visibility = View.INVISIBLE   // чтобы сам таймер не попал в кадр
        h.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    bar?.visibility = View.VISIBLE
                    val hb = r.hardwareBuffer
                    val full = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (full != null) onShot(crop(full))
                }
                override fun onFailure(errorCode: Int) {
                    bar?.visibility = View.VISIBLE
                    Toast.makeText(this@PresenceService, "Скриншот не удался ($errorCode)", Toast.LENGTH_SHORT).show()
                }
            })
        }, 80)
    }

    private fun crop(full: Bitmap): Bitmap {
        val r = Rect()
        val w = windows.firstOrNull { it.root?.packageName?.toString() == CHROME }
        w?.getBoundsInScreen(r)
        if (r.isEmpty) r.set(0, 0, full.width, full.height / 2)   // запасной вариант: верхняя половина
        if (!r.intersect(0, 0, full.width, full.height) || r.width() < 10 || r.height() < 10) return full
        return Bitmap.createBitmap(full, r.left, r.top, r.width(), r.height())
    }

    private fun onShot(bmp: Bitmap) {
        // файл для перетаскивания
        val dir = File(cacheDir, "shots").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "shot_${System.currentTimeMillis()}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

        // копия в галерею
        runCatching {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, f.name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PresenceCompanion")
            }
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)?.let { u ->
                contentResolver.openOutputStream(u)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
        }

        // копия в буфер обмена (вставляется в ИИ долгим нажатием в поле ввода)
        runCatching {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newUri(contentResolver, "screenshot", uri))
        }

        // миниатюра слева внизу, поверх окна ИИ: тап — убрать, долгое нажатие — перетащить в приложение
        val iv = ImageView(ui).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xCC000000.toInt())
            setPadding(dp(3), dp(3), dp(3), dp(3))
            setOnClickListener { removeThumb() }
            setOnLongClickListener { v ->
                val clip = ClipData.newUri(contentResolver, "screenshot", uri)
                v.startDragAndDrop(
                    clip, View.DragShadowBuilder(v), null,
                    View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ
                )
                true
            }
        }
        val lp = overlayParams(dp(110), dp(190), Gravity.BOTTOM or Gravity.START)
            .apply { x = dp(10); y = dp(10) }
        wm.addView(iv, lp)
        thumb = iv
    }

    private fun removeThumb() {
        thumb?.let { runCatching { wm.removeView(it) } }
        thumb = null
    }
}
