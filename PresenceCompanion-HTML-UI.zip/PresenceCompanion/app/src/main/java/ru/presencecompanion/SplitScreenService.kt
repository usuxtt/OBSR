package ru.presencecompanion

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Служба «Специальные возможности»: единственная задача — включить разделённый экран
 * и вернуть приложение в нижнюю половину. Содержимое окон не читает.
 */
class SplitScreenService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: SplitScreenService? = null

        // Паузы подобраны наугад и зависят от прошивки: при необходимости менять здесь
        private const val DELAY_TOGGLE_MS = 1200L
        private const val DELAY_OPEN_APP_MS = 1300L
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    /** Chrome уже запущен: делим экран (Chrome остаётся сверху), затем открываем шторку внизу. */
    fun runFlow() {
        handler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
        }, DELAY_TOGGLE_MS)

        handler.postDelayed({
            val open = Intent(this, MainActivity::class.java)
                .addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
                .putExtra("flow", "picker")
            startActivity(open)
        }, DELAY_TOGGLE_MS + DELAY_OPEN_APP_MS)
    }
}
