package ru.presencecompanion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

class FloatingPanelService : Service() {

    companion object {
        const val ACTION_UPDATE_STATE = "ru.presencecompanion.UPDATE_STATE"
        const val EXTRA_IS_AWAY = "is_away"
        const val EXTRA_AWAY_START_MS = "away_start_ms"
        const val EXTRA_MULTIPLIER_ACTIVE = "multiplier_active"
        private const val THRESHOLD_MS = 5_000L
        private const val CHANNEL_ID = "floating_panel"
        private const val NOTIFICATION_ID = 8
    }

    private lateinit var windowManager: WindowManager
    private var panelView: View? = null
    private lateinit var timerText: TextView
    private lateinit var stateText: TextView

    private var isAway = false
    private var awayStartMs = 0L
    private var multiplierActive = false

    private val handler = Handler(Looper.getMainLooper())
    private val tickRunnable = object : Runnable {
        override fun run() {
            if (panelView == null) return
            renderCountdown()
            handler.postDelayed(this, 100L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startAsForegroundService()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#E6161922"))
            setPadding(28, 22, 28, 22)
        }

        stateText = TextView(this).apply {
            text = "ФОКУС: НА МЕСТЕ"
            textSize = 12f
            setTextColor(Color.parseColor("#8CE99A"))
        }

        timerText = TextView(this).apply {
            text = "5.0 с | ×1"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 6, 0, 12)
        }

        val openAppBtn = Button(this).apply {
            text = "Снимок / ИИ"
            textSize = 12f
            setOnClickListener {
                val intent = Intent(this@FloatingPanelService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(intent)
            }
        }

        val closeBtn = Button(this).apply {
            text = "Скрыть"
            textSize = 12f
            setOnClickListener { stopSelf() }
        }

        container.addView(stateText)
        container.addView(timerText)
        container.addView(openAppBtn)
        container.addView(closeBtn)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 110
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (initialTouchX - event.rawX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    params.x = (initialX + deltaX).coerceAtLeast(0)
                    params.y = (initialY + deltaY).coerceAtLeast(0)
                    windowManager.updateViewLayout(container, params)
                    true
                }
                else -> false
            }
        }

        panelView = container
        windowManager.addView(container, params)
        handler.post(tickRunnable)
    }

    private fun startAsForegroundService() {
        createNotificationChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Presence Companion")
            .setContentText("Плавающая панель активна")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(false)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Floating panel",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE_STATE) {
            isAway = intent.getBooleanExtra(EXTRA_IS_AWAY, false)
            awayStartMs = intent.getLongExtra(EXTRA_AWAY_START_MS, 0L)
            multiplierActive = intent.getBooleanExtra(EXTRA_MULTIPLIER_ACTIVE, false)
            renderCountdown()
        }
        return START_NOT_STICKY
    }

    private fun renderCountdown() {
        if (!isAway || awayStartMs == 0L) {
            stateText.text = "ФОКУС: НА МЕСТЕ"
            stateText.setTextColor(Color.parseColor("#8CE99A"))
            val mult = if (multiplierActive) "×3" else "×1"
            timerText.text = "5.0 с | $mult"
            timerText.setTextColor(Color.WHITE)
            return
        }

        val elapsed = System.currentTimeMillis() - awayStartMs
        val remaining = (THRESHOLD_MS - elapsed).coerceAtLeast(0L)

        stateText.text = "НЕТ ФОКУСА"
        stateText.setTextColor(Color.parseColor("#FFA94D"))

        if (remaining > 0L) {
            timerText.text = String.format("%.1f с | ×1", remaining / 1000.0)
            timerText.setTextColor(Color.parseColor("#FFD43B"))
        } else {
            val overtimeSec = (elapsed - THRESHOLD_MS) / 1000.0
            timerText.text = String.format("0.0 с (+%.1f с) | ×3!", overtimeSec)
            timerText.setTextColor(Color.parseColor("#FF6B6B"))
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tickRunnable)
        panelView?.let { windowManager.removeView(it) }
        panelView = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
