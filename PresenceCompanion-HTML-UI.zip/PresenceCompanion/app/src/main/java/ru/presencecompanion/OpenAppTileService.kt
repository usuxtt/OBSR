package ru.presencecompanion

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/**
 * Плитка быстрых настроек: Chrome -> разделённый экран -> шторка выбора ИИ.
 * Если служба специальных возможностей выключена, открывает её настройки.
 */
class OpenAppTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = getString(R.string.tile_label)
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()

        val service = SplitScreenService.instance
        if (service == null) {
            Toast.makeText(
                this,
                "Включите Presence Companion в «Специальных возможностях»",
                Toast.LENGTH_LONG
            ).show()
            collapseAndStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        val chrome = packageManager.getLaunchIntentForPackage("com.android.chrome")
        if (chrome == null) {
            Toast.makeText(this, "Chrome не найден", Toast.LENGTH_SHORT).show()
            collapseAndStart(Intent(this, MainActivity::class.java))
            return
        }

        collapseAndStart(chrome)
        service.runFlow()
    }

    private fun collapseAndStart(base: Intent) {
        val intent = Intent(base).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            // API 34+: startActivityAndCollapse(Intent) удалён, нужен PendingIntent.
            // Но PendingIntent.getActivity из фона может быть заблокирован,
            // поэтому сначала пробуем напрямую (плитка — foreground UI).
            try {
                startActivity(intent)
            } catch (e: Exception) {
                val pending = PendingIntent.getActivity(
                    this, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pending)
            }
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
