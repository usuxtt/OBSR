package ru.presencecompanion

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/**
 * Quick Settings entry point for the existing Presence Companion flow.
 * The tile UI itself is rendered by Android SystemUI; this service only
 * supplies its state, label/icon metadata and click action.
 */
class PresenceQuickSettingsTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onTileAdded() {
        super.onTileAdded()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        val accessibilityService = SplitScreenService.instance
        if (accessibilityService == null) {
            Toast.makeText(
                this,
                "Сначала включите Presence Companion в специальных возможностях",
                Toast.LENGTH_LONG
            ).show()
            launchFromTile(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        val chromeIntent = packageManager.getLaunchIntentForPackage(CHROME_PACKAGE)
        if (chromeIntent == null) {
            Toast.makeText(this, "Google Chrome не установлен", Toast.LENGTH_SHORT).show()
            launchFromTile(Intent(this, MainActivity::class.java))
            return
        }

        // Start Chrome from the tile interaction, then continue the same
        // accessibility-driven split-screen and AI picker sequence.
        launchFromTile(chromeIntent)
        accessibilityService.runFlow()
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        tile.label = getString(R.string.tile_label)
        tile.contentDescription = getString(R.string.tile_description)
        tile.state = if (SplitScreenService.instance != null) {
            Tile.STATE_ACTIVE
        } else {
            Tile.STATE_INACTIVE
        }
        tile.updateTile()
    }

    private fun launchFromTile(target: Intent) {
        val launchIntent = Intent(target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pendingIntent = PendingIntent.getActivity(
                    this,
                    4107,
                    launchIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pendingIntent)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(launchIntent)
            }
        } catch (_: Exception) {
            // Fallback for vendor SystemUI implementations with stricter collapse handling.
            try {
                startActivity(launchIntent)
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val CHROME_PACKAGE = "com.android.chrome"

        /** Can be called by app code to ask SystemUI to refresh this tile. */
        fun requestRefresh(context: android.content.Context) {
            requestListeningState(
                context,
                ComponentName(context, PresenceQuickSettingsTileService::class.java)
            )
        }
    }
}
