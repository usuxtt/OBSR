package com.presence.companion

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        val start = Button(this).apply {
            text = "СТАРТ"
            textSize = 24f
            setOnClickListener { onStart() }
        }
        col.addView(TextView(this).apply {
            text = "OBSR"; textSize = 36f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(0x3D, 0xDC, 0x84)); setBackgroundColor(Color.rgb(0x0F, 0x1B, 0x14))
            setPadding(pad, pad / 2, pad, pad / 2)
        })
        col.addView(status, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = pad })
        col.addView(start, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = pad })
        setContentView(col)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (PresenceService.instance != null)
            "Служба включена ✓\nНажми СТАРТ: откроется Chrome, снизу появится выбор ИИ."
        else
            "Служба выключена.\nНажми СТАРТ и включи «OBSR» в службах специальных возможностей."
    }

    private fun onStart() {
        val s = PresenceService.instance
        if (s == null) {
            Toast.makeText(this, "Включи службу OBSR и вернись сюда", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else {
            s.start()
        }
    }
}
